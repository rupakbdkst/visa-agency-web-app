<?php
require_once 'config.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    redirect('index.php');
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $full_name = cleanInput($_POST['full_name']);
        $phone = cleanInput($_POST['phone']);
        $district = cleanInput($_POST['district']);
        $nid_number = cleanInput($_POST['nid_number']);
        $passport_number = cleanInput($_POST['passport_number']);
        
        $stmt = $pdo->prepare("UPDATE users SET full_name = ?, phone = ?, district = ?, nid_number = ?, passport_number = ? WHERE id = ?");
        if ($stmt->execute([$full_name, $phone, $district, $nid_number, $passport_number, $user_id])) {
            $message = "Profile updated successfully.";
            $_SESSION['full_name'] = $full_name;
        } else {
            $error = "Failed to update profile.";
        }
        
        // Handle File Uploads
        $doc_types = ['nid_front', 'nid_back', 'passport_copy', 'cv', 'driving_license', 'edu_cert', 'photo'];
        
        foreach ($doc_types as $type) {
            if (isset($_FILES[$type]) && $_FILES[$type]['error'] == 0) {
                $upload = uploadFile($_FILES[$type], 'uploads/');
                if (isset($upload['success'])) {
                    // Check if doc exists
                    $stmt = $pdo->prepare("SELECT id FROM user_documents WHERE user_id = ? AND doc_type = ?");
                    $stmt->execute([$user_id, $type]);
                    if ($stmt->fetch()) {
                        $update = $pdo->prepare("UPDATE user_documents SET file_path = ? WHERE user_id = ? AND doc_type = ?");
                        $update->execute([$upload['success'], $user_id, $type]);
                    } else {
                        $insert = $pdo->prepare("INSERT INTO user_documents (user_id, doc_type, file_path) VALUES (?, ?, ?)");
                        $insert->execute([$user_id, $type, $upload['success']]);
                    }
                } else {
                    $error .= "Error uploading $type: " . $upload['error'] . "<br>";
                }
            }
        }
    }
}

// Fetch User Data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$documents = getUserDocuments($pdo, $user_id);
$visa_status = getLatestVisaStatus($pdo, $user_id);

require_once 'includes/header.php';
?>

<div class="card">
    <div class="card-header">
        User Profile 
        <span style="float:right; font-size: 0.8em;" class="badge badge-<?php echo ($visa_status == 'Approved') ? 'success' : (($visa_status == 'Rejected') ? 'danger' : 'warning'); ?>">
            Visa Status: <?php echo ucfirst($visa_status); ?>
        </span>
    </div>
    
    <?php if ($message): ?>
        <div class="alert alert-success"><?php echo $message; ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST" action="" enctype="multipart/form-data" id="main-form">
        <input type="hidden" name="update_profile" value="1">
        
        <div class="row" style="display:flex; flex-wrap:wrap; gap:20px;">
            <div class="col" style="flex:1; min-width:300px;">
                <h3>Personal Information</h3>
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled style="background:#eee;">
                </div>
                <div class="form-group">
                    <label>District</label>
                    <select name="district" required>
                        <?php foreach(getDistricts() as $dist): ?>
                            <option value="<?php echo $dist; ?>" <?php echo ($user['district'] == $dist) ? 'selected' : ''; ?>><?php echo $dist; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>NID Number</label>
                    <input type="text" name="nid_number" value="<?php echo htmlspecialchars($user['nid_number']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Passport Number</label>
                    <input type="text" name="passport_number" value="<?php echo htmlspecialchars($user['passport_number'] ?? ''); ?>">
                </div>
            </div>
            
            <div class="col" style="flex:1; min-width:300px;">
                <h3>Documents</h3>
                <?php 
                $file_labels = [
                    'photo' => 'Profile Photo (Passport Size)',
                    'nid_front' => 'NID Front',
                    'nid_back' => 'NID Back',
                    'passport_copy' => 'Passport Copy',
                    'cv' => 'CV Upload',
                    'driving_license' => 'Driving License',
                    'edu_cert' => 'Last Educational Certificate'
                ];
                
                foreach ($file_labels as $key => $label): 
                ?>
                <div class="form-group">
                    <label><?php echo $label; ?></label>
                    <?php if (isset($documents[$key])): ?>
                        <p style="font-size:0.9em; margin-bottom:5px;">
                            Current: <a href="<?php echo $documents[$key]; ?>" target="_blank">View File</a>
                        </p>
                    <?php endif; ?>
                    <input type="file" name="<?php echo $key; ?>" accept=".jpg,.jpeg,.png,.pdf">
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </form>
</div>

<!-- Chat Section -->
<div class="card">
    <div class="card-header">Chat with Admin</div>
    <div class="chat-box" id="chat-messages">
        <!-- Messages will be loaded here via AJAX or PHP include -->
        <?php
        $messages = getMessages($pdo, $user_id);
        if (empty($messages)) {
            echo "<p style='color:#777; text-align:center;'>No messages yet.</p>";
        } else {
            foreach ($messages as $msg) {
                $class = ($msg['sender_id'] == $user_id) ? 'sent' : 'received';
                echo "<div class='message $class'>" . htmlspecialchars($msg['message']) . "</div>";
            }
        }
        ?>
    </div>
    <form action="send_message.php" method="POST" style="display:flex; gap:10px;">
        <input type="hidden" name="receiver_id" value="1"> <!-- 1 is Admin -->
        <input type="text" name="message" placeholder="Type a message..." required style="flex:1;">
        <button type="submit" class="btn btn-primary">Send</button>
    </form>
</div>

<?php 
$nextPage = 'visa.php';
require_once 'includes/footer.php'; 
?>
