<?php
$host = 'sql305.iceiy.com';
$dbname = 'icei_41040656_visa_agency';
$username = 'icei_41040656';
$password = 'fSztp6mEKaP2';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

session_start();
?>
