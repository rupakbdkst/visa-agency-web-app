<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Adjust paths based on location
$is_admin_dir = strpos($_SERVER['SCRIPT_NAME'], '/admin/') !== false;
$base_path = $is_admin_dir ? '../' : '';

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visa Agency System</title>
    <link rel="stylesheet" href="<?php echo $base_path; ?>css/style.css">
</head>
<body>

<header>
    <div class="container navbar">
        <div class="logo">
            <h2><a href="<?php echo $base_path; ?>index.php" style="color:white; text-decoration:none;">Visa Agency</a></h2>
        </div>
        <nav class="nav-links">
            <?php if (isLoggedIn()): ?>
                <?php if (isAdmin()): ?>
                    <a href="<?php echo $base_path; ?>admin/dashboard.php">Admin Panel</a>
                    <a href="<?php echo $base_path; ?>logout.php">Logout</a>
                <?php else: ?>
                    <a href="<?php echo $base_path; ?>profile.php">Profile</a>
                    <a href="<?php echo $base_path; ?>visa.php">Visa Info</a>
                    <a href="<?php echo $base_path; ?>logout.php">Logout</a>
                <?php endif; ?>
            <?php else: ?>
                <a href="<?php echo $base_path; ?>index.php">Login</a>
                <a href="<?php echo $base_path; ?>register.php">Register</a>
            <?php endif; ?>
        </nav>
    </div>
</header>

<div class="container main-content" style="padding-top: 20px;">
    <!-- Main Content Starts Here -->
