<?php
// includes/functions.php

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function cleanInput($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

function uploadFile($file, $destination, $allowedTypes = ['jpg', 'jpeg', 'png', 'pdf']) {
    $targetDir = __DIR__ . "/../uploads/";
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    
    $fileName = basename($file["name"]);
    $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $newFileName = uniqid() . "." . $fileType;
    $targetFilePath = $targetDir . $newFileName;
    
    if (!in_array($fileType, $allowedTypes)) {
        return ["error" => "Only JPG, PNG & PDF files are allowed."];
    }
    
    if ($file["size"] > 5000000) { // 5MB limit
        return ["error" => "File is too large."];
    }
    
    if (move_uploaded_file($file["tmp_name"], $targetFilePath)) {
        return ["success" => "uploads/" . $newFileName];
    } else {
        return ["error" => "There was an error uploading your file."];
    }
}

function getDistricts() {
    return [
        "Dhaka", "Faridpur", "Gazipur", "Gopalganj", "Kishoreganj", "Madaripur", "Manikganj", "Munshiganj", "Narayanganj", "Narsingdi", "Rajbari", "Shariatpur", "Tangail", 
        "Bagerhat", "Chuadanga", "Jessore", "Jhenaidah", "Khulna", "Kushtia", "Magura", "Meherpur", "Narail", "Satkhira", 
        "Bogra", "Chapainawabganj", "Joypurhat", "Naogaon", "Natore", "Pabna", "Rajshahi", "Sirajganj", 
        "Dinajpur", "Gaibandha", "Kurigram", "Lalmonirhat", "Nilphamari", "Panchagarh", "Rangpur", "Thakurgaon", 
        "Habiganj", "Moulvibazar", "Sunamganj", "Sylhet", 
        "Barguna", "Barisal", "Bhola", "Jhalokati", "Patuakhali", "Pirojpur", 
        "Bandarban", "Brahmanbaria", "Chandpur", "Chittagong", "Comilla", "Cox's Bazar", "Feni", "Khagrachari", "Lakshmipur", "Noakhali", "Rangamati", 
        "Jamalpur", "Mymensingh", "Netrokona", "Sherpur"
    ];
}

function getUserDocuments($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT doc_type, file_path FROM user_documents WHERE user_id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
}

function getLatestVisaStatus($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT status FROM visa_applications WHERE user_id = ? ORDER BY created_at DESC LIMIT 1");
    $stmt->execute([$user_id]);
    return $stmt->fetchColumn() ?: 'Not Applied';
}

function getMessages($pdo, $user_id, $admin_id = null) {
    // If admin_id is null, it means we are getting messages for the user (from/to any admin, or specifically the system admin)
    // For simplicity, we assume one admin or chat is with 'System Admin' (user_id 1)
    $admin_id = 1; // Default admin ID
    $stmt = $pdo->prepare("SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY created_at ASC");
    $stmt->execute([$user_id, $admin_id, $admin_id, $user_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
