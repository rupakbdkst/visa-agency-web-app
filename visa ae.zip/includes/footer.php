</div> <!-- End Main Content -->

<?php if (isLoggedIn()): ?>
<div class="action-bar">
    <?php 
    // Logic for Home button
    $homeLink = isAdmin() ? ($base_path . 'admin/dashboard.php') : ($base_path . 'profile.php');
    // Logic for Exit button
    $exitLink = $base_path . 'logout.php';
    ?>
    <a href="<?php echo $homeLink; ?>" class="btn btn-secondary">Home</a>
    
    <button type="submit" form="main-form" class="btn btn-success">Save</button>
    
    <?php if (isset($nextPage)): ?>
        <a href="<?php echo $nextPage; ?>" class="btn btn-primary">Next</a>
    <?php else: ?>
        <button class="btn btn-secondary" disabled>Next</button>
    <?php endif; ?>
    
    <a href="<?php echo $exitLink; ?>" class="btn btn-danger">Exit</a>
</div>
<?php endif; ?>

<script src="<?php echo $base_path; ?>js/script.js"></script>
</body>
</html>
