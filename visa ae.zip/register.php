<?php
require_once 'config.php';
require_once 'includes/functions.php';

if (isLoggedIn()) {
    redirect('profile.php');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = cleanInput($_POST['full_name']);
    $phone = cleanInput($_POST['phone']);
    $email = cleanInput($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $district = cleanInput($_POST['district']);
    $nid_number = cleanInput($_POST['nid_number']);

    // Check if email exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        $error = "Email already registered.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO users (full_name, phone, email, password, district, nid_number) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt->execute([$full_name, $phone, $email, $password, $district, $nid_number])) {
            $success = "Registration successful! You can now <a href='index.php'>login</a>.";
        } else {
            $error = "Registration failed. Please try again.";
        }
    }
}

require_once 'includes/header.php';
?>

<div class="card" style="max-width: 600px; margin: 50px auto;">
    <div class="card-header">User Registration</div>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <form method="POST" action="">
        <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="full_name" required>
        </div>
        <div class="form-group">
            <label>Phone Number</label>
            <input type="text" name="phone" required>
        </div>
        <div class="form-group">
            <label>Email Address</label>
            <input type="email" name="email" required>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>
        <div class="form-group">
            <label>District</label>
            <select name="district" required>
                <option value="">Select District</option>
                <?php foreach(getDistricts() as $dist): ?>
                    <option value="<?php echo $dist; ?>"><?php echo $dist; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>NID Number</label>
            <input type="text" name="nid_number" required>
        </div>
        <button type="submit" class="btn btn-primary" style="width: 100%;">Register</button>
    </form>
    <p style="margin-top: 15px; text-align: center;">
        Already have an account? <a href="index.php">Login here</a>
    </p>
</div>

<?php require_once 'includes/footer.php'; ?>
