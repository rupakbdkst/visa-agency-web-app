<?php
require_once 'config.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    redirect('index.php');
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Handle New Application
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['apply_visa'])) {
    $country = cleanInput($_POST['country']);
    
    if (isset($_FILES['visa_doc']) && $_FILES['visa_doc']['error'] == 0) {
        $upload = uploadFile($_FILES['visa_doc'], 'uploads/');
        if (isset($upload['success'])) {
            $stmt = $pdo->prepare("INSERT INTO visa_applications (user_id, country, document_path) VALUES (?, ?, ?)");
            if ($stmt->execute([$user_id, $country, $upload['success']])) {
                $message = "Visa application submitted successfully.";
            } else {
                $error = "Database error.";
            }
        } else {
            $error = "Upload failed: " . $upload['error'];
        }
    } else {
        $error = "Please upload the required visa document.";
    }
}

// Fetch Applications
$stmt = $pdo->prepare("SELECT * FROM visa_applications WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once 'includes/header.php';
?>

<div class="card">
    <div class="card-header">Visa Application</div>
    
    <?php if ($message): ?>
        <div class="alert alert-success"><?php echo $message; ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST" action="" enctype="multipart/form-data" id="main-form">
        <input type="hidden" name="apply_visa" value="1">
        
        <div class="form-group">
            <label>Select Country</label>
            <select name="country" required>
                <option value="">Select Country</option>
                <option value="USA">USA</option>
                <option value="UK">UK</option>
                <option value="Canada">Canada</option>
                <option value="Australia">Australia</option>
                <option value="Dubai">Dubai</option>
                <option value="Saudi Arabia">Saudi Arabia</option>
                <option value="Malaysia">Malaysia</option>
                <option value="Singapore">Singapore</option>
                <!-- Add more as needed -->
            </select>
        </div>
        
        <div class="form-group">
            <label>Visa Document Upload (Image / PDF)</label>
            <input type="file" name="visa_doc" accept=".jpg,.jpeg,.png,.pdf" required>
        </div>
        
        <!-- The footer Save button will submit this form because of id="main-form" -->
        <button type="submit" class="btn btn-primary">Submit Application</button>
    </form>
</div>

<div class="card">
    <div class="card-header">My Applications</div>
    <table>
        <thead>
            <tr>
                <th>Country</th>
                <th>Status</th>
                <th>Document</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($applications)): ?>
                <tr><td colspan="4">No applications found.</td></tr>
            <?php else: ?>
                <?php foreach ($applications as $app): ?>
                <tr>
                    <td><?php echo htmlspecialchars($app['country']); ?></td>
                    <td>
                        <span class="badge badge-<?php echo ($app['status'] == 'approved') ? 'success' : (($app['status'] == 'rejected') ? 'danger' : 'warning'); ?>">
                            <?php echo ucfirst($app['status']); ?>
                        </span>
                    </td>
                    <td><a href="<?php echo $app['document_path']; ?>" target="_blank">View</a></td>
                    <td><?php echo date('d M Y', strtotime($app['created_at'])); ?></td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php 
// Next page logic? Maybe back to home or stay here. 
// "Home, Next, Save, Exit".
// If this is Page 2, maybe Next goes nowhere or back to Profile? 
// I'll set next page to Profile for now, or just leave it blank.
$nextPage = 'profile.php'; 
require_once 'includes/footer.php'; 
?>
