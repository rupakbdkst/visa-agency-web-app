<?php
require_once '../config.php';
require_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../index.php');
}

if (!isset($_GET['id'])) {
    redirect('dashboard.php');
}

$user_id = $_GET['id'];
$message = '';
$error = '';

// Handle Profile Update
if (isset($_POST['update_profile'])) {
    $full_name = cleanInput($_POST['full_name']);
    $phone = cleanInput($_POST['phone']);
    $district = cleanInput($_POST['district']);
    $nid_number = cleanInput($_POST['nid_number']);
    $passport_number = cleanInput($_POST['passport_number']);
    
    $stmt = $pdo->prepare("UPDATE users SET full_name = ?, phone = ?, district = ?, nid_number = ?, passport_number = ? WHERE id = ?");
    if ($stmt->execute([$full_name, $phone, $district, $nid_number, $passport_number, $user_id])) {
        $message = "User profile updated.";
    } else {
        $error = "Failed to update profile.";
    }
}

// Handle Visa Status Update
if (isset($_POST['update_visa_status'])) {
    $visa_id = $_POST['visa_id'];
    $status = $_POST['status'];
    
    $stmt = $pdo->prepare("UPDATE visa_applications SET status = ? WHERE id = ?");
    $stmt->execute([$status, $visa_id]);
    $message = "Visa status updated.";
}

// Handle Visa Document Upload by Admin
if (isset($_POST['upload_visa_doc'])) {
    $visa_id = $_POST['visa_id'];
    if (isset($_FILES['admin_doc']) && $_FILES['admin_doc']['error'] == 0) {
        $upload = uploadFile($_FILES['admin_doc'], '../uploads/'); // Note path adjustment
        if (isset($upload['success'])) {
            // Remove '../' from path for DB storage if we want relative to root, 
            // but uploadFile returns 'uploads/file'. 
            // If we are in admin, uploadFile puts it in ../uploads/. 
            // The return value is 'uploads/file'.
            // When accessing from root, 'uploads/file' is correct.
            // When accessing from admin, '../uploads/file' is correct.
            // We store 'uploads/file' in DB.
            $stmt = $pdo->prepare("UPDATE visa_applications SET document_path = ? WHERE id = ?");
            $stmt->execute([$upload['success'], $visa_id]);
            $message = "Visa document uploaded.";
        } else {
            $error = "Upload failed: " . $upload['error'];
        }
    }
}

// Fetch User Data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "User not found.";
    exit;
}

$documents = getUserDocuments($pdo, $user_id);
$visa_applications = $pdo->prepare("SELECT * FROM visa_applications WHERE user_id = ? ORDER BY created_at DESC");
$visa_applications->execute([$user_id]);
$visas = $visa_applications->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        User Details: <?php echo htmlspecialchars($user['full_name']); ?>
        <button onclick="window.print()" class="btn btn-secondary" style="float:right;">Print</button>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-success"><?php echo $message; ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST" action="" id="main-form">
        <input type="hidden" name="update_profile" value="1">
        <div class="row" style="display:flex; gap:20px;">
            <div class="col" style="flex:1;">
                <h3>Profile Information</h3>
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>">
                </div>
                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>">
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="text" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>District</label>
                    <input type="text" name="district" value="<?php echo htmlspecialchars($user['district']); ?>">
                </div>
                <div class="form-group">
                    <label>NID</label>
                    <input type="text" name="nid_number" value="<?php echo htmlspecialchars($user['nid_number']); ?>">
                </div>
                <div class="form-group">
                    <label>Passport</label>
                    <input type="text" name="passport_number" value="<?php echo htmlspecialchars($user['passport_number']); ?>">
                </div>
            </div>
            <div class="col" style="flex:1;">
                <h3>Uploaded Documents</h3>
                <ul>
                <?php foreach ($documents as $type => $path): ?>
                    <li>
                        <strong><?php echo ucfirst(str_replace('_', ' ', $type)); ?>:</strong> 
                        <a href="../<?php echo $path; ?>" target="_blank">View File</a>
                    </li>
                <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <!-- Button in footer submits this -->
    </form>
</div>

<div class="card">
    <div class="card-header">Visa Applications</div>
    <table>
        <thead>
            <tr>
                <th>Country</th>
                <th>User Doc</th>
                <th>Status</th>
                <th>Admin Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($visas as $visa): ?>
            <tr>
                <td><?php echo htmlspecialchars($visa['country']); ?></td>
                <td><a href="../<?php echo $visa['document_path']; ?>" target="_blank">View</a></td>
                <td>
                    <form method="POST" action="" style="display:inline;">
                        <input type="hidden" name="update_visa_status" value="1">
                        <input type="hidden" name="visa_id" value="<?php echo $visa['id']; ?>">
                        <select name="status" onchange="this.form.submit()">
                            <option value="pending" <?php echo ($visa['status'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
                            <option value="approved" <?php echo ($visa['status'] == 'approved') ? 'selected' : ''; ?>>Approved</option>
                            <option value="rejected" <?php echo ($visa['status'] == 'rejected') ? 'selected' : ''; ?>>Rejected</option>
                        </select>
                    </form>
                </td>
                <td>
                    <form method="POST" action="" enctype="multipart/form-data" style="display:flex; gap:5px;">
                        <input type="hidden" name="upload_visa_doc" value="1">
                        <input type="hidden" name="visa_id" value="<?php echo $visa['id']; ?>">
                        <input type="file" name="admin_doc" required style="width:150px;">
                        <button type="submit" class="btn btn-secondary" style="padding:2px 5px;">Upload</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Chat Section -->
<div class="card">
    <div class="card-header">Chat with User</div>
    <div class="chat-box" id="chat-messages">
        <?php
        $messages = getMessages($pdo, $user_id);
        foreach ($messages as $msg) {
            // Here 'sent' means sent by Admin (me), 'received' means sent by User
            // Since we are Admin (ID 1), if sender_id == 1, it's sent.
            $class = ($msg['sender_id'] == 1) ? 'sent' : 'received';
            echo "<div class='message $class'>" . htmlspecialchars($msg['message']) . "</div>";
        }
        ?>
    </div>
    <form action="../send_message.php" method="POST" style="display:flex; gap:10px;">
        <input type="hidden" name="receiver_id" value="<?php echo $user_id; ?>">
        <input type="text" name="message" placeholder="Type a message..." required style="flex:1;">
        <button type="submit" class="btn btn-primary">Send</button>
    </form>
</div>

<?php require_once '../includes/footer.php'; ?>
