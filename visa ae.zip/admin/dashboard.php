<?php
require_once '../config.php';
require_once '../includes/functions.php';

if (!isAdmin()) {
    redirect('../index.php');
}

$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';

$sql = "SELECT u.*, 
        (SELECT status FROM visa_applications WHERE user_id = u.id ORDER BY created_at DESC LIMIT 1) as visa_status,
        (SELECT country FROM visa_applications WHERE user_id = u.id ORDER BY created_at DESC LIMIT 1) as visa_country
        FROM users u WHERE u.role = 'user'";

$params = [];

if ($search) {
    $sql .= " AND (u.full_name LIKE ? OR u.phone LIKE ? OR u.email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Note: Filtering by status is done in PHP or complex subquery WHERE clause. 
// For simplicity, let's just fetch and filter or use HAVING.
if ($status_filter) {
    $sql .= " HAVING visa_status = ?";
    $params[] = $status_filter;
}

$sql .= " ORDER BY u.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>

<div class="card">
    <div class="card-header">Admin Dashboard - Users List</div>
    
    <form method="GET" action="" class="form-group" style="display:flex; gap:10px;">
        <input type="text" name="search" placeholder="Search by Name, Phone, Email" value="<?php echo htmlspecialchars($search); ?>">
        <select name="status">
            <option value="">All Statuses</option>
            <option value="pending" <?php echo ($status_filter == 'pending') ? 'selected' : ''; ?>>Pending</option>
            <option value="approved" <?php echo ($status_filter == 'approved') ? 'selected' : ''; ?>>Approved</option>
            <option value="rejected" <?php echo ($status_filter == 'rejected') ? 'selected' : ''; ?>>Rejected</option>
            <option value="Not Applied" <?php echo ($status_filter == 'Not Applied') ? 'selected' : ''; ?>>Not Applied</option>
        </select>
        <button type="submit" class="btn btn-primary">Filter</button>
        <a href="dashboard.php" class="btn btn-secondary">Reset</a>
        <button type="button" onclick="window.print()" class="btn btn-success">Print Report</button>
    </form>
    
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Phone</th>
                <th>District</th>
                <th>Latest Visa</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
            <tr>
                <td><?php echo $user['id']; ?></td>
                <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                <td><?php echo htmlspecialchars($user['phone']); ?></td>
                <td><?php echo htmlspecialchars($user['district']); ?></td>
                <td><?php echo htmlspecialchars($user['visa_country'] ?? 'N/A'); ?></td>
                <td>
                    <span class="badge badge-<?php echo ($user['visa_status'] == 'approved') ? 'success' : (($user['visa_status'] == 'rejected') ? 'danger' : 'warning'); ?>">
                        <?php echo ucfirst($user['visa_status'] ?? 'None'); ?>
                    </span>
                </td>
                <td>
                    <a href="user_details.php?id=<?php echo $user['id']; ?>" class="btn btn-primary" style="padding:5px 10px; font-size:12px;">View / Edit</a>
                    <a href="delete_user.php?id=<?php echo $user['id']; ?>" class="btn btn-danger" style="padding:5px 10px; font-size:12px;" onclick="return confirm('Are you sure?');">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require_once '../includes/footer.php'; ?>
